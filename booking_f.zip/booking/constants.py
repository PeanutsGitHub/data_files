from selenium.webdriver.common.by import By

BASE_URL = "https://www.booking.com"
EXPORT_FILE = "Hotel-Booking.txt"

# Menu Bar "Choose your currency"
index_choose_you_currency_by = By.CSS_SELECTOR
index_choose_you_currency_value = 'button[data-tooltip-text="Choose your currency"]'
index_selected_currency_by = By.CSS_SELECTOR
index_selected_currency_pvalue = 'a[data-modal-header-async-url-param*="selected_currency={currency}"]' # {currency}

